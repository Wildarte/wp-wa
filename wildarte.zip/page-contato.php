<?php get_header();
//Template Name: Contato
?>
    
    <main>
        
        <section class="head_archive">
            <div class="container header_post_page head_default">
                <h1 class="color-white">Contato</h1>
            </div>
        </section>

        <section class="container p-10">
            <div class="hr-gray"></div>
        </section>

        <section class="">

            <section class="container list_post_simple d-flex content_form">

                <div class="over_form_contact">
                    <form action="">
                        <input type="text" name="" id="">
                        <input type="text" name="" id="">
                        <input type="text" name="" id="">
                        <textarea name="" id="" cols="30" rows="10"></textarea>
                        <input type="submit" value="Enviar">
                    </form>
                </div>

            </section>

        </section>

    </main>

<?php get_footer(); ?>